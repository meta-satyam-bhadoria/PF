package myjava.util;

import java.util.Arrays;

public class ArrayList<T> implements List<T>{
	private T[] array = null;
	private int size = 1;
	private int index = 0;
	
	public ArrayList () {
		this.array = createArray(1);
	}
	
	public void add (T item) {
		if(this.index == this.size){
			this.array = Arrays.copyOf(this.array, ++this.size);
		}
		this.array[this.index++] = item;
	}
	
	public void add (int itemIndex, T item){
		if (itemIndex > this.size) {
			this.array = Arrays.copyOf (this.array, itemIndex);
			this.index = itemIndex;
			this.size = itemIndex;
			
		} else {
			this.array = Arrays.copyOf (this.array, ++this.size);
			for (int i = array.length - 1; i >= itemIndex; i--) {
				this.array[i] = this.array[i - 1];
			}
			this.index++;
		}
		this.array[itemIndex - 1] = item;
	}
	
	public void remove (int itemIndex) {
		if (itemIndex <= this.size) {
			this.array = append ( Arrays.copyOfRange(this.array, 0, itemIndex - 1) , Arrays.copyOfRange(this.array, itemIndex, this.array.length));
		}
	}
	
	public void remove (T item) {
		for (int i = 0; i < this.size; i++) {
			if (this.array[i] == item) {
				this.array = append ( Arrays.copyOfRange(this.array, 0, i) , Arrays.copyOfRange(this.array, i + 1, this.array.length));
				break;
			}
		}
	}
	
	public int indexOf (T item) {
		for (int i = 0; i < this.size; i++) {
			if (this.array[i] == item) {
				return i;
			}
		}
		return -1;
	}
	
	public int indexOf (int location, T item) {
		for (int i = location - 1; i < this.size; i++) {
			if (this.array[i] == item) {
				return i;
			}
		}
		return -1;
	}
	
	public void clear () {
		this.array = createArray(1);
	}
	
	public void sort () {
		Arrays.sort(this.array);
	}
	
	public void reverse () {
		for (int i = 0, j = this.array.length - 1; i < j; i++, j--) {
			T temp = this.array[i];
			this.array[i] = this.array[j];
			this.array[j] = temp;
		}
	}
	
	public void append (T[] arrayAppend) {
		this.array = append (this.array , arrayAppend);
		this.size += arrayAppend.length;
		this.index += arrayAppend.length;
	}
	
	public void append (ArrayList<T> listToAdd) {
		this.array = append (this.array , listToAdd.array);
		this.size += listToAdd.size;
		this.index += listToAdd.index;
	}
	
	private T[] append (T[] firstArray, T[] secondArray) {
		T[] arr = createArray(firstArray.length + secondArray.length);
		System.arraycopy(firstArray, 0, arr, 0, firstArray.length);
		System.arraycopy(secondArray, 0, arr, firstArray.length, secondArray.length);
		return arr;
	}
	
	@SuppressWarnings("unchecked")
	private T[] createArray (int arrSize) {
		return (T[]) new Object[arrSize];
	} 
	
	public T[] display () {
		for (int i = 0; i < this.array.length; i++) {
			System.out.println(this.array[i]);
		}
		return this.array;
	}
}