package myjava.util;

import java.util.Arrays;

public class Doubly<T> {
	private Node<T> start;
	private Node<T> end;
	private int size;
	
	public Doubly () {
		this.start = null;
		this.end = null;
		this.size = 0;
	}
	
	public void add (T item){
        Node<T> nptr = new Node<>(null, item);    
        this.size++ ;    
        if(this.start == null) 
        {
            this.start = nptr;
            this.end = this.start;
        }
        else 
        {
        	nptr.setPreviousLink(end);
            this.end.setNextLink(nptr);
            this.end = nptr;
        }
    }
	
	public void add (int position, T item) {
		if(position == 1){
	        Node<T> nptr = new Node<>(null, item); 
	        nptr.setNextLink(this.start);
	        this.start = nptr;
			return;
			
		} else if(position > this.size){
			for(int i = this.size; i < position - 1; i++)
				this.add(null);
			this.add(item);
			return;
		}
        Node<T> nptr = new Node<>(null, item);                
        Node<T> ptr = this.start;
        position = position - 1 ;
        for (int i = 0; i <= this.size; i++) 
        {
            if (i == position) 
            {
            	nptr.setNextLink(ptr.getNextLink());
                ptr.setNextLink(nptr);
                nptr.setPreviousLink(ptr);
                nptr.getNextLink().setPreviousLink(nptr);
                break;
            }
            ptr = ptr.getNextLink();
        }
        this.size++ ;
	}
	
	public void remove (T item) {
		 Node<T> ptr = this.start;
		 int i = 0;
		 while (ptr != null) {
			 i++;
			 if (item == ptr.getData()){
				 remove (i);
				 break;
			 }
			 ptr = ptr.getNextLink();
		 }
		 System.out.println("Item Not Found");
	}
	
	public void remove (int position) {
		if(this.size == 0){
			System.out.println("Underflow");
			return;
			
		} else if(this.size == 1){
			this.start = null;
			this.size = 0;
			return;
			
		} else if(position == 1){
			this.start = this.start.getNextLink();
			this.start.setPreviousLink(null);
	        this.size--;
	        return;
	        
		} else if (position == this.size) {
            remove ();
            return;
            
        } else if(position < size/2){
			removeFromStart(position);
			
        }
		else{
			removeFromEnd(position);
		}
		System.out.println("Item Not Found");
	}
	
	private void removeFromStart(int position){
		 
        Node<T> ptr = this.start;
        position = position - 1;
        for (int i = 1; i < this.size - 1; i++) {
            if (i == position) {
            	ptr.getNextLink().getNextLink().setPreviousLink(ptr);
                ptr.setNextLink(ptr.getNextLink().getNextLink());	           
                this.size-- ;
                return;
            }
            ptr = ptr.getNextLink();
        }
	}
	private void removeFromEnd(int position){
	    Node<T> ptr = this.end;
        position = position - 1;
        for (int i = this.size; i > 0; i--) {
            if (i == position) {
            	ptr.getNextLink().getNextLink().setPreviousLink(ptr);
                ptr.setNextLink( ptr.getNextLink().getNextLink () );	           
                this.size-- ;
                return;
            }
            ptr = ptr.getPreviousLink();
        }
	}
	private void remove () {
		if(this.size == 0){
			System.out.println("Underflow");
			return;
		}
        this.end.getPreviousLink().setNextLink(null);
        this.end = this.end.getPreviousLink();
        this.size--;
        return;
	}
	
	public int indexOf (T item) {
		Node<T> ptr = this.start;
		for (int i = 0; i < this.size; i++) {
			if (ptr.getData() == item) {
				return i;
			}
			ptr = ptr.getNextLink();
		}
		return -1;
	}
	
	public T itemAt (int position) {
		Node<T> ptr = this.start;
		int i = 1;
		while ( i != position) {
			ptr = ptr.getNextLink();
		}
		return ptr.getData();
	}
	
	public void reverse () {
		Node<T> ptr = this.start;
		if(ptr != null){
			for (int i = 0 ;i < this.size && ptr.getNextLink() != null; i++) {
				Node<T> temp = ptr.getNextLink();
				ptr.setNextLink(temp.getNextLink());
				temp.setNextLink(this.start);
				this.start = temp;
			}
		}
	}
	
	public void sort (){
		@SuppressWarnings("unchecked")
		T[] arr = toArray((T[]) new Object[this.size]);
		Arrays.sort(arr);
		
		Node<T> ptr = this.start;
		int i = 0;
		while (ptr != null) {
			ptr.setData(arr[i++]);
			ptr = ptr.getNextLink();
		}
	}
	
	public T[] toArray (T[] arr) {
		Node<T> ptr = this.start;
		int i = 0;
		while (ptr != null) {
			arr[i++] = ptr.getData();
			ptr = ptr.getNextLink();
		}
		return arr;
	}
	
	public void display () {
		Node<T> ptr = this.start;
		while (ptr != null) {
			System.out.println(ptr.getData());
			ptr = ptr.getNextLink();
		}
	}
	
}

