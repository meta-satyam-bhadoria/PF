package myjava.util;

public interface List<T> {
	public void add(T item);
	public T[] display();
}
