package myjava.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayListTest {

	@Test
	public void test() {
		List<String> s = new ArrayList<>();
		s.add("1");
		s.add("2");
		s.add("3");
		String[] expected = new String[] {"1","2","3"};
		assertArrayEquals(expected, s.display());  
	}
}
